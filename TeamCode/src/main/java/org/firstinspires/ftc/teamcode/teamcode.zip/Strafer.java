package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;

import com.qualcomm.robotcore.eventloop.opmode.TeleOp;

import com.qualcomm.robotcore.hardware.DcMotor;

import com.qualcomm.robotcore.util.ElapsedTime;

@TeleOp(name="Strafer", group="TeleOp")

public class Strafer extends LinearOpMode {

    private ElapsedTime runtime = new ElapsedTime();

    private DcMotor leftFrontDrive;

    private DcMotor leftBackDrive;

    private DcMotor rightFrontDrive;

    private DcMotor rightBackDrive;

    private DcMotor intake;

    private DcMotor transfer;

    @Override

    public void runOpMode() {

        leftFrontDrive = hardwareMap.get(DcMotor.class, "left_front_drive");

        leftBackDrive = hardwareMap.get(DcMotor.class, "left_back_drive");

        rightFrontDrive = hardwareMap.get(DcMotor.class, "right_front_drive");

        rightBackDrive = hardwareMap.get(DcMotor.class, "right_back_drive");

        intake = hardwareMap.get(DcMotor.class, "intake");

        transfer = hardwareMap.get(DcMotor.class, "transfer");

        // Motor directions

        leftFrontDrive.setDirection(DcMotor.Direction.REVERSE);

        leftBackDrive.setDirection(DcMotor.Direction.FORWARD);

        rightFrontDrive.setDirection(DcMotor.Direction.FORWARD);

        rightBackDrive.setDirection(DcMotor.Direction.REVERSE);

        // Reverse transfer so it spins in the same physical direction as intake

        transfer.setDirection(DcMotor.Direction.REVERSE);

        // Brake when joystick is released

        leftFrontDrive.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        leftBackDrive.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        rightFrontDrive.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        rightBackDrive.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        intake.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        transfer.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        telemetry.addData("Status", "Initialized");

        telemetry.update();

        waitForStart();

        runtime.reset();

        boolean intakeOn = false;

        double intakePower = 0;

        boolean rightTriggerPressed = false;

        boolean leftTriggerPressed = false;

        while (opModeIsActive()) {

            // Left joystick = forward/backward and strafe

            double axial = -gamepad1.left_stick_y;

            double lateral = gamepad1.left_stick_x;

            // Right joystick = turn

            double yaw = gamepad1.right_stick_x;

            // Speed modes

            double speed = 1.0;

            if (gamepad1.right_bumper) {

                speed = 1.0;

            }

            if (gamepad1.left_bumper) {

                speed = 0.50;

            }

            // Mecanum calculations

            double leftFrontPower = axial + lateral + yaw;

            double rightFrontPower = axial - lateral - yaw;

            double leftBackPower = axial - lateral + yaw;

            double rightBackPower = axial + lateral - yaw;

            // Normalize so no wheel goes above 1.0

            double max = Math.max(

                    Math.abs(leftFrontPower),

                    Math.abs(rightFrontPower)

            );

            max = Math.max(max, Math.abs(leftBackPower));

            max = Math.max(max, Math.abs(rightBackPower));

            if (max > 1.0) {

                leftFrontPower /= max;

                rightFrontPower /= max;

                leftBackPower /= max;

                rightBackPower /= max;

            }

            // Apply speed

            leftFrontPower *= speed;

            rightFrontPower *= speed;

            leftBackPower *= speed;

            rightBackPower *= speed;

            // Send power to drive motors

            leftFrontDrive.setPower(leftFrontPower);

            rightFrontDrive.setPower(rightFrontPower);

            leftBackDrive.setPower(leftBackPower);

            rightBackDrive.setPower(rightBackPower);

            // Intake and transfer trigger detection

            boolean rightTrigger = gamepad1.right_trigger > 0.5;

            boolean leftTrigger = gamepad1.left_trigger > 0.5;

            // Right trigger: toggle inward

            if (rightTrigger && !rightTriggerPressed) {

                if (intakeOn && intakePower > 0) {

                    intakeOn = false;

                    intakePower = 0;

                } else {

                    intakeOn = true;

                    intakePower = 1.0;

                }

            }

            // Left trigger: toggle outward

            if (leftTrigger && !leftTriggerPressed) {

                if (intakeOn && intakePower < 0) {

                    intakeOn = false;

                    intakePower = 0;

                } else {

                    intakeOn = true;

                    intakePower = -1.0;

                }

            }

            // Remember trigger states

            rightTriggerPressed = rightTrigger;

            leftTriggerPressed = leftTrigger;

            // Apply power to both motors

            intake.setPower(intakePower);

            transfer.setPower(intakePower);

            // Telemetry

            telemetry.addData("Run Time", runtime.toString());

            if (gamepad1.right_bumper) {

                telemetry.addData("Mode", "TURBO - RB");

            } else if (gamepad1.left_bumper) {

                telemetry.addData("Mode", "SLOW - LB");

            } else {

                telemetry.addData("Mode", "NORMAL");

            }

            telemetry.addData("Speed", speed);

            telemetry.addData("Front Left", leftFrontPower);

            telemetry.addData("Front Right", rightFrontPower);

            telemetry.addData("Back Left", leftBackPower);

            telemetry.addData("Back Right", rightBackPower);

            if (intakePower > 0) {

                telemetry.addData("Intake + Transfer", "ON - INWARD");

            } else if (intakePower < 0) {

                telemetry.addData("Intake + Transfer", "ON - OUTWARD");

            } else {

                telemetry.addData("Intake + Transfer", "OFF");

            }

            telemetry.update();

        }

    }

}