package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.util.ElapsedTime;

@TeleOp(name = "TeleOp2", group = "Linear Opmode")
public class TeleOp2 extends LinearOpMode {

    private DcMotorEx leftFrontDrive;
    private DcMotorEx leftBackDrive;
    private DcMotorEx rightFrontDrive;
    private DcMotorEx rightBackDrive;

    private DcMotor intake;
    private DcMotor transfer;
    private DcMotorEx flywheel;
    private DcMotor turret;

    private Servo ramp;
    private Servo arm;

    private static final double NORMAL_SPEED = 1.0;
    private static final double TURBO_SPEED = 1.0;
    private static final double SLOW_SPEED = 1.0;

    private static final double RAMP_MAX_ANGLE = 45.0;
    private static final double SERVO_MAX_ANGLE = 180.0;
    private static final double RAMP_SPEED = 45.0;

    //shut the fuck up chat gpt.

    // Turret joystick speed is limited to 25% power.
    private static final double TURRET_POWER = 0.25;
    private static final double TURRET_DEADZONE = 0.08;

    // ARM SETTINGS
    private static final double ARM_REFERENCE_POSITION = 0.5;
    private static final double ARM_SERVO_RANGE = 300.0;
    private static final double ARM_START_ANGLE = 60.0;
    private static final double ARM_MAX_CCW_ANGLE = ARM_START_ANGLE;
    private static final double ARM_SPEED = 45.0;

    // Intake activates after 30% of the arm's clockwise travel.
    private static final double ARM_ACTIVATION_PERCENT = 0.30;

    private double driveSpeed = NORMAL_SPEED;

    // Driver 1 intake controls
    private int intakeMode = 0;
    private boolean driver1IntakeOverride = false;

    // Driver 2 automatic sequence
    private boolean sequenceOn = false;

    // Flywheel starts OFF. Driver 2 RT toggles it ON/OFF.




    private boolean previousDpadUp2 = false;
    private boolean previousDpadDown2 = false;

    private boolean previousRightTrigger1 = false;
    private boolean previousLeftTrigger1 = false;

    private boolean previousRightBumper1 = false;
    private boolean previousLeftBumper1 = false;

    private boolean previousRightTrigger2 = false;

    private double rampAngle = 0.0;
    private double armAngle = -ARM_START_ANGLE;

    private ElapsedTime rampTimer = new ElapsedTime();

    @Override
    public void runOpMode() {

        leftFrontDrive = hardwareMap.get(DcMotorEx.class, "left_front_drive");
        leftBackDrive = hardwareMap.get(DcMotorEx.class, "left_back_drive");
        rightFrontDrive = hardwareMap.get(DcMotorEx.class, "right_front_drive");
        rightBackDrive = hardwareMap.get(DcMotorEx.class, "right_back_drive");
    
        intake = hardwareMap.get(DcMotor.class, "intake");
        transfer = hardwareMap.get(DcMotor.class, "transfer");
        flywheel = hardwareMap.get(DcMotorEx.class, "flywheel");

        // Read the configured motor's encoder specifications for TPS and RPM.
        turret = hardwareMap.get(DcMotor.class, "turret");

        ramp = hardwareMap.get(Servo.class, "ramp");
        arm = hardwareMap.get(Servo.class, "arm");

        // Drive motor directions
        leftFrontDrive.setDirection(DcMotor.Direction.REVERSE);
        leftBackDrive.setDirection(DcMotor.Direction.FORWARD);
        rightFrontDrive.setDirection(DcMotor.Direction.FORWARD);
        rightBackDrive.setDirection(DcMotor.Direction.REVERSE);
        flywheel.setMode(DcMotor.RunMode.RUN_USING_ENCODER);

        // Mechanism motor directions
        transfer.setDirection(DcMotor.Direction.REVERSE);
        flywheel.setDirection(DcMotor.Direction.REVERSE);

        // Brake motors when no power is applied
        leftFrontDrive.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        leftBackDrive.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        rightFrontDrive.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        rightBackDrive.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);

        intake.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        transfer.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        flywheel.setZeroPowerBehavior(DcMotorEx.ZeroPowerBehavior.BRAKE);
        turret.setZeroPowerBehavior(DcMotor.ZeroPowerBehavior.BRAKE);
        //intializing all flywheel variables (because chat gpts method is lowkeygay)
        double flywheelcpr = 28.0;
        double flywheelinputrpm = 3000;
        double flywheeltargetrpm = 0;
        boolean flywheelon = false;
        double flywheelvelocitytps = flywheeltargetrpm*flywheelcpr/60;
        double flywheelactualrpm = (flywheel.getVelocity()*60)/flywheelcpr;
        double flywheelrpmchange = 0;

        // Initialize ramp
        rampAngle = 0.0;
        ramp.setPosition(0.0);

        // Initialize arm at 60 degrees counterclockwise
        armAngle = -ARM_START_ANGLE;

        double initialArmPosition =
                ARM_REFERENCE_POSITION +
                (armAngle / ARM_SERVO_RANGE);

        arm.setPosition(initialArmPosition);

        // Keep the flywheel OFF until Driver 2 presses RT.
        flywheelon = false;
        flywheel.setVelocity(0.0);

        telemetry.addLine("Lunar Flare TeleOp Ready");
        telemetry.addData("Drive Speed", "Normal");
        telemetry.addData("Arm Angle", armAngle);
        telemetry.addData("Arm Position", initialArmPosition);
        telemetry.addData("Sequence", "OFF");
        telemetry.addData("Flywheel", "OFF");
        telemetry.addData("Flywheel Target RPM ",
                flywheeltargetrpm);
        telemetry.addData("Turret", "Ready");
        telemetry.update();

        waitForStart();

        rampTimer.reset();

        while (opModeIsActive()) {

            // =====================================
            // DRIVER 1 - DRIVE CONTROLS
            // =====================================

            double axial = -gamepad1.left_stick_y;
            double lateral = gamepad1.left_stick_x;
            double yaw = gamepad1.right_stick_x;
            double speed = 1.0;
            if (gamepad1.right_bumper) {
                speed = 1.0;
            }
            if (gamepad1.left_bumper) {
                speed = 0.50;
            }
            double leftFrontPower = axial + lateral + yaw;

            double rightFrontPower = axial - lateral - yaw;

            double leftBackPower = axial - lateral + yaw;

            double rightBackPower = axial + lateral - yaw;

            // Normalize so no wheel goes above 1.0

            double max = Math.max(

                    Math.abs(leftFrontPower),

                    Math.abs(rightFrontPower)

            );

            max = Math.max(max, Math.abs(leftBackPower));

            max = Math.max(max, Math.abs(rightBackPower));

            if (max > 1.0) {

                leftFrontPower /= max;

                rightFrontPower /= max;

                leftBackPower /= max;

                rightBackPower /= max;

            }
            leftFrontPower *= speed;

            rightFrontPower *= speed;

            leftBackPower *= speed;

            rightBackPower *= speed;
            leftFrontDrive.setPower(leftFrontPower);

            rightFrontDrive.setPower(rightFrontPower);

            leftBackDrive.setPower(leftBackPower);

            rightBackDrive.setPower(rightBackPower);

            // =====================================
            // DRIVER 1 - INTAKE AND TRANSFER
            // =====================================

            boolean rightTrigger1 = gamepad1.right_trigger > 0.5;
            boolean leftTrigger1 = gamepad1.left_trigger > 0.5;

            if (rightTrigger1 && !previousRightTrigger1) {

                driver1IntakeOverride = true;

                if (intakeMode == 1) {
                    intakeMode = 0;
                } else {
                    intakeMode = 1;

            }

            if (leftTrigger1 && !previousLeftTrigger1) {

                driver1IntakeOverride = true;

                if (intakeMode == -1) {
                    intakeMode = 0;
                } else {
                    intakeMode = -1;
                }
            }

            previousRightTrigger1 = rightTrigger1;
            previousLeftTrigger1 = leftTrigger1;


            // =====================================
            // DRIVER 2 - FLYWHEEL SPEED
            // =====================================

            boolean dpadUp2 = gamepad2.dpad_up;
            boolean dpadDown2 = gamepad2.dpad_down;
            if (dpadUp2) {
                flywheelrpmchange++;
            }

            if (dpadDown2) {
                flywheelrpmchange--;
            }
            if (flywheelrpmchange>=5){
                flywheelinputrpm+=5;
                flywheelinputrpm = 0;
            }
            if (flywheelrpmchange<=-5){
                flywheelinputrpm-=5;
                flywheelinputrpm = 0;
            }


            // =====================================
            // DRIVER 2 - AUTOMATIC SEQUENCE
            // =====================================

            boolean rightTrigger2 = gamepad2.right_trigger > 0.5;

            if (rightTrigger2 && !previousRightTrigger2) {

                sequenceOn = !sequenceOn;
                flywheelon = !flywheelon;

                if (!sequenceOn) {
                    intakeMode = 0;
                    driver1IntakeOverride = false;
                }
            }

            previousRightTrigger2 = rightTrigger2;


            // =====================================
            // SHARED TIMER
            // =====================================

            double elapsedTime = rampTimer.seconds();
            rampTimer.reset();


            // =====================================
            // DRIVER 2 - DEPLOYABLE RAMP
            // =====================================

            boolean rampClockwise = gamepad2.right_bumper;
            boolean rampCounterClockwise = gamepad2.left_bumper;

            if (rampClockwise && !rampCounterClockwise) {
                rampAngle += RAMP_SPEED * elapsedTime;
            } else if (rampCounterClockwise && !rampClockwise) {
                rampAngle -= RAMP_SPEED * elapsedTime;
            }

            rampAngle = Math.max(
                    0.0,
                    Math.min(RAMP_MAX_ANGLE, rampAngle)
            );

            double rampPosition = rampAngle / SERVO_MAX_ANGLE;
            ramp.setPosition(rampPosition);


            // =====================================
            // DRIVER 2 - AUTOMATIC ARM SERVO
            // =====================================

            if (sequenceOn) {

                // Move clockwise toward 0 degrees.
                armAngle += ARM_SPEED * elapsedTime;

            } else {

                // Return to original starting position.
                armAngle -= ARM_SPEED * elapsedTime;
            }

            // Keep arm within its limits.
            armAngle = Math.max(
                    -ARM_MAX_CCW_ANGLE,
                    Math.min(2.0, armAngle)
            );

            double armPosition =
                    ARM_REFERENCE_POSITION +
                    (armAngle / ARM_SERVO_RANGE);

            arm.setPosition(armPosition);


            // =====================================
            // AUTOMATIC INTAKE AND FLYWHEEL
            // =====================================

            double activationAngle =
                    -ARM_START_ANGLE * (1.0 - ARM_ACTIVATION_PERCENT);

            boolean automaticIntakeOn =
                    sequenceOn && armAngle >= activationAngle;

            // Driver 1 has priority over automatic intake.
            double intakePower;

            if (sequenceOn && driver1IntakeOverride) {

                if (intakeMode == 1) {
                    intakePower = 1.0;
                } else if (intakeMode == -1) {
                    intakePower = -1.0;
                } else {
                    intakePower = 0.0;
                }

            } else if (automaticIntakeOn) {

                intakePower = 1.0;

            } else if (sequenceOn) {

                intakePower = 0.0;

            } else if (driver1IntakeOverride) {

                if (intakeMode == 1) {
                    intakePower = 1.0;
                } else if (intakeMode == -1) {
                    intakePower = -1.0;
                } else {
                    intakePower = 0.0;
                }

            } else {

                intakePower = 0.0;
            }

            intake.setPower(intakePower);
            transfer.setPower(intakePower);


            // =====================================
            // FLYWHEEL POWER
            // =====================================
            if (flywheelon){
                flywheeltargetrpm = flywheelinputrpm;
            }else{
                flywheeltargetrpm = 0;
            }
            flywheelvelocitytps = flywheeltargetrpm*flywheelcpr/60;
            flywheelactualrpm = (flywheel.getVelocity()*60)/flywheelcpr;
            flywheel.setVelocity(flywheelvelocitytps);
            
            
            


            // =====================================
            // DRIVER 2 - TURRET
            // =====================================

            double turretInput = gamepad2.left_stick_x;

            if (Math.abs(turretInput) < TURRET_DEADZONE) {
                turretInput = 0.0;
            }

            turret.setPower(turretInput * TURRET_POWER);


            // =====================================
            // TELEMETRY
            // =====================================

            telemetry.addData("Drive Speed", driveSpeed);

            telemetry.addData("Driver 1 Intake Mode", intakeMode);
            telemetry.addData("Driver 1 Override", driver1IntakeOverride);
            telemetry.addData("Intake Power", intakePower);

            telemetry.addData("Sequence", sequenceOn ? "ON" : "OFF");
            telemetry.addData("Automatic Intake",
                    automaticIntakeOn ? "ON" : "OFF");

            telemetry.addData("Flywheel", flywheelon ? "ON" : "OFF");
            telemetry.addData("Flywheel Set RPM", "%.1f", flywheeltargetrpm);
            telemetry.addData("Flywheel Input RPM", "%.1f", flywheelinputrpm);
            telemetry.addData("Flywheel Actual RPM", "%.1f", flywheelactualrpm);

            telemetry.addData("Ramp Angle", "%.1f", rampAngle);
            telemetry.addData("Ramp Position", "%.3f", rampPosition);

            telemetry.addData("Arm Angle", "%.1f", armAngle);
            telemetry.addData("Arm Position", "%.4f", armPosition);
            telemetry.addData("Activation Angle", "%.1f", activationAngle);

            telemetry.addData("Turret Power", "%.2f", turret.getPower());

            telemetry.update();
        }

        // Stop motors when OpMode ends
        leftFrontDrive.setPower(0.0);
        leftBackDrive.setPower(0.0);
        rightFrontDrive.setPower(0.0);
        rightBackDrive.setPower(0.0);

        intake.setPower(0.0);
        transfer.setPower(0.0);
        flywheel.setPower(0.0);
        turret.setPower(0.0);
    }
}
}